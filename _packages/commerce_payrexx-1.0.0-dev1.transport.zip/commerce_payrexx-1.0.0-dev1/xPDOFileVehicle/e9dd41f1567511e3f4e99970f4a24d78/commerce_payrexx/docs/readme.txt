Payrexx for Commerce
------------------------

Payment Gateway for Commerce supporting the Payrexx platform. Payrexx is based out of
Switzerland and supports a wide range of Payment Service Providers and Payment Methods
applicable to users from across Europe.

The integration enables plug & play use of Payrexx as a Redirect integration. This means
the customer will choose the Payrexx option during the Commerce checkout, and be sent to
the Payrexx hosted payment page to complete. After paying, they'll return to Commerce.
