<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'MIT License

Copyright (c) 2023 modmore <support@modmore.com>

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
',
    'readme' => 'Payrexx for Commerce
------------------------

Payment Gateway for Commerce supporting the Payrexx platform. Payrexx is based out of
Switzerland and supports a wide range of Payment Service Providers and Payment Methods
applicable to users from across Europe.

The integration enables plug & play use of Payrexx as a Redirect integration. This means
the customer will choose the Payrexx option during the Commerce checkout, and be sent to
the Payrexx hosted payment page to complete. After paying, they\'ll return to Commerce.
',
    'changelog' => 'Payrexx for Commerce 1.0.0-rc1
------------------------------
Released on 2023-02-13

- First release
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '5d3af6615428cf2dc08a8e7f7e322290',
      'native_key' => 'commerce_payrexx',
      'filename' => 'modNamespace/b3e64bf160a1aabf05f8aa153b0199d2.vehicle',
      'namespace' => 'commerce_payrexx',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '9dadede8c24c545d77a44a2825122a72',
      'native_key' => '9dadede8c24c545d77a44a2825122a72',
      'filename' => 'xPDOFileVehicle/e9dd41f1567511e3f4e99970f4a24d78.vehicle',
    ),
  ),
);